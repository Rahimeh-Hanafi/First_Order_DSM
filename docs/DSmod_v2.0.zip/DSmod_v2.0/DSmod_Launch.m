clear
clc
close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%                        First Order Sigma Delta                          %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Tstop = 2500;               % Simulation stop-time
InFreq = 8e-03;             % Input signal freq.
SamplFreq = 1;              % Sampling Freq.
Vref = 1;                   % Full-scale reference (+_ Vref)
Vfs = 2*Vref;               % Full-Scale voltage
Nbit=1;                     % number of bits of quantizer
Ampl=0.85;                  % Amplitude of the input sine wave
dc=0.55;                    % DC input
Ksine=1;                    % Sine wave Flag: 1 -> on  0 -> off
Kdc=0;                      % DC input Flag:  1 -> on  0 -> off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%                        Start Simulink Simulation                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

options=simset('InitialStep', 1, 'RelTol', 1e-3);
sim('DSmod.mdl',Tstop, options);

fprintf('End of Sim\n')